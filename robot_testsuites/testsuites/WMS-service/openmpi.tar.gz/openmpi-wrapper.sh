#!/bin/bash

# The binary to execute
EXE=$1
MPI_PATH=$MPI_OPENMPI_PATH

echo "***********************************************************************"
echo "gLite informations:"
echo "-------------------"
echo ""
echo "gLite user: "`whoami`
echo "Working directory: "`pwd`
echo ""
echo "***********************************************************************"



echo "***********************************************************************"
echo "Compiling binary: $EXE"

cmd="make"
echo $cmd
$cmd
if [ ! $? -eq 0 ]; then
    echo "Error compiling program.  Exiting..."
    exit 1
fi

# Everything's OK.
echo "Successfully compiled ${EXE}"
echo "***********************************************************************"



echo "***********************************************************************"
echo "Copying files to all nodes using the SSH_HOST_BASED_AUTH method"

if [ "x${MPI_SSH_HOST_BASED_AUTH}" != "xyes" ] ; then
    echo "You must activate SSH_HOST_BASED_AUTH to be able to run mpi jobs on this cluster"
    exit 1
fi

if [ "x$PBS_NODEFILE" != "x" ] ; then
    echo "Machines running this mpi application will be :"
    cat $PBS_NODEFILE
    HOST_NODEFILE=$PBS_NODEFILE
else
    echo "variable PBS_NODEFILE undefined... abort"
    exit 1
fi

HOST_NEEDED=`cat ${HOST_NODEFILE} | wc -l | awk '{print $NF}'`

for i in `cat $HOST_NODEFILE | grep -v ${HOSTNAME} | sort -u`; do
    echo "Sending files to ${i}"
    ssh ${i} mkdir -p `pwd`
    scp -rp . "${i}:`pwd`"
    scp -p ${X509_USER_PROXY} ${i}:${X509_USER_PROXY}
done

echo "Successfully sent files"
echo "***********************************************************************"



echo "***********************************************************************"
echo "Launching mpd daemons and starting MPI binary: $EXE"
chmod +x `pwd`/${EXE}
$MPI_PATH/bin/mpiexec -np ${HOST_NEEDED} --hostfile ${HOST_NODEFILE} --tag-output `pwd`/${EXE}
echo "***********************************************************************"



echo "***********************************************************************"
echo "Cleaning everything up"
for i in `cat $HOST_NODEFILE | grep -v ${HOSTNAME} | sort -u`; do
    echo "Cleaning on host ${i}"
    ssh ${i} rm -rf /home/`whoami`/globus*
    ssh ${i} rm -rf /home/`whoami`/.mpd.conf
done
echo "***********************************************************************"
